#!/bin/sh
./arithoh.sh &
./syscall.sh &
wait