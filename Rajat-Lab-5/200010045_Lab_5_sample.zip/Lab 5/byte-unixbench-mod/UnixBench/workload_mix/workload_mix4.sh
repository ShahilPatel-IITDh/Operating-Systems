#!/bin/sh
./syscall.sh &
./fstime.sh &
./arithoh.sh &
./arithoh.sh &
./fstime.sh &
wait
