#!/bin/sh
./fstime.sh &
./pipe.sh &
./spawn.sh &
wait