#!/bin/sh

./spawn.sh &
./spawn.sh &
./arithoh.sh &
./arithoh.sh &
./spawn.sh &
wait