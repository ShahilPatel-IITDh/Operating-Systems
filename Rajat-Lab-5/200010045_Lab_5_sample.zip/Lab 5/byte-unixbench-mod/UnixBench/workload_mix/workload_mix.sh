#!/bin/sh
./arithoh.sh &
./fstime.sh &
./pipe.sh &
./spawn.sh &
./syscall.sh &
./arithoh.sh &
./fstime.sh &
./pipe.sh &
./spawn.sh &
./syscall.sh &
wait
