#!/bin/sh

./pipe.sh &
./pipe.sh &
./syscall.sh &
./pipe.sh &
./pipe.sh &
wait